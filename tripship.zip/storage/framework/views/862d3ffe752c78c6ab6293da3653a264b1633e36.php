<!DOCTYPE html>
<html>

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="<?php echo e(asset('/')); ?>assets/front/css/bootstrap.min.css">
        <!-- Boxicons CSS -->
        <link rel="stylesheet" href="<?php echo e(asset('/')); ?>assets/front/css/boxicons.min.css">
        <!-- Magnific Popup CSS -->
        <link rel="stylesheet" href="<?php echo e(asset('/')); ?>assets/front/css/magnific-popup.min.css">
        <!-- Owl Carousel -->
        <link rel="stylesheet" href="<?php echo e(asset('/')); ?>assets/front/css/owl.carousel.min.css">
        <link rel="stylesheet" href="<?php echo e(asset('/')); ?>assets/front/css/owl.theme.default.min.css">
        <!-- Slick Slider CSS -->
        <link rel="stylesheet" href="<?php echo e(asset('/')); ?>assets/front/css/slick.min.css">
        <link rel="stylesheet" href="<?php echo e(asset('/')); ?>assets/front/css/slick-theme.min.css">
        <!-- Meanmenu JS -->
        <link rel="stylesheet" href="<?php echo e(asset('/')); ?>assets/front/css/meanmenu.css">
        <!-- Nice Select JS -->
        <link rel="stylesheet" href="<?php echo e(asset('/')); ?>assets/front/css/nice-select.min.css">
        <!-- Progressbar CSS -->
        <link rel="stylesheet" href="<?php echo e(asset('/')); ?>assets/front/css/progressbar.min.css">
        <!-- Animate CSS -->
        <link rel="stylesheet" href="<?php echo e(asset('/')); ?>assets/front/css/animate.min.css">
        <!-- Swiper Slider CSS -->
        <link rel="stylesheet" href="<?php echo e(asset('/')); ?>assets/front/css/swiper.min.css">
        <!-- Style CSS -->
        <link rel="stylesheet" href="<?php echo e(asset('/')); ?>assets/front/css/style.css">
        <!-- Responsive CSS -->
        <link rel="stylesheet" href="<?php echo e(asset('/')); ?>assets/front/css/responsive.css">
        <link rel="stylesheet" href="<?php echo e(asset('/')); ?>assets/front/cs/google-translate.css">

        <title>Tripshiptask</title>

        <link rel="icon" type="image/png" href="<?php echo e(asset('/')); ?>assets/front/img/ride/favicon.png">

        <style>
            iframe#\:1\.container {
                display: none;
            }
        </style>
    </head>

    <body data-spy="scroll" data-offset="70">

        <?php echo $__env->make('front.inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo $__env->yieldContent('main-body'); ?>

        <?php echo $__env->make('front.inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



        <!-- Essential JS -->
        <script src="<?php echo e(asset('/')); ?>assets/front/js/jquery.min.js"></script>
        <script src="<?php echo e(asset('/')); ?>assets/front/js/popper.min.js"></script>
        <script src="<?php echo e(asset('/')); ?>assets/front/js/bootstrap.min.js"></script>
        <!-- Magnific Popup JS -->
        <script src="<?php echo e(asset('/')); ?>assets/front/js/jquery.magnific-popup.min.js"></script>
        <!-- Owl Carousel JS -->
        <script src="<?php echo e(asset('/')); ?>assets/front/js/owl.carousel.min.js"></script>
        <!-- Form Ajaxchimp JS -->
        <script src="<?php echo e(asset('/')); ?>assets/front/js/jquery.ajaxchimp.min.js"></script>
        <!-- Form Validator JS -->
        <script src="<?php echo e(asset('/')); ?>assets/front/js/form-validator.min.js"></script>
        <!-- Contact JS -->
        <script src="<?php echo e(asset('/')); ?>assets/front/js/contact-form-script.js"></script>
        <!-- Meanmenu JS -->
        <script src="<?php echo e(asset('/')); ?>assets/front/js/jquery.meanmenu.js"></script>
        <!-- Slick Slider JS -->
        <script src="<?php echo e(asset('/')); ?>assets/front/js/slick.min.js"></script>
        <!-- Nice Select JS -->
        <script src="<?php echo e(asset('/')); ?>assets/front/js/jquery.nice-select.min.js"></script>
        <!-- Progressbar JS -->
        <script src="<?php echo e(asset('/')); ?>assets/front/js/progressbar.min.js"></script>
        <!-- Wow JS -->
        <script src="<?php echo e(asset('/')); ?>assets/front/js/wow.min.js"></script>
        <!-- Swiper Slider JS -->
        <script src="<?php echo e(asset('/')); ?>assets/front/js/swiper.min.js"></script>

        <!-- Custom JS -->
        <script src="<?php echo e(asset('/')); ?>assets/front/js/custom.js"></script>

        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-cookie/1.4.1/jquery.cookie.min.js"></script>
        


    </body>

</html>
<?php /**PATH C:\xampp\htdocs\tripship\resources\views/front/master/app.blade.php ENDPATH**/ ?>