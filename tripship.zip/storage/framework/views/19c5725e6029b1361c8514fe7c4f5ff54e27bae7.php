

<?php $__env->startSection('main-body'); ?>
<div class="main-body">

    <!-- Start Sign Up Area -->
    <section class="user-area-all-style sign-up-area ptb-100">
        <div class="container">
            <div class="contact-form-action">
                <form method="POST" action="<?php echo e(route('register')); ?>">
                    <div class="row">

                        <div class="col-md-12 col-sm-12">
                            <div class="form-group">
                                <input class="form-control" type="text" name="name"
                                  placeholder="<?php echo e(__('Enter your Username')); ?>">
                            </div>
                        </div>

                        <div class="col-md-12 col-sm-12">
                            <div class="form-group">
                                <input class="form-control" type="email" name="email"
                                  placeholder="<?php echo e(__('Email Address')); ?>">
                            </div>
                        </div>

                        <div class="col-md-12 col-sm-12">
                            <div class="form-group">
                                <input class="form-control" type="text" name="password"
                                  placeholder="<?php echo e(__('Password')); ?>">
                            </div>
                        </div>

                        <div class="col-md-12 col-sm-12 ">
                            <div class="form-group">
                                <input class="form-control" type="text" name="password"
                                  placeholder="<?php echo e(__('Confirm Password')); ?>">
                            </div>
                        </div>
                        

                        <div class="col-12">
                            <button class="default-btn btn-two" type="submit">
                                Register Account
                            </button>
                        </div>

                        <div class="col-12">
                            <p class="account-desc">
                                Already have an account?
                                <a href="<?php echo e(route('login')); ?>"> Log In</a>
                            </p>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </section>
    <!-- End Sign Up Area -->
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.master.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tripship\resources\views/auth/register.blade.php ENDPATH**/ ?>