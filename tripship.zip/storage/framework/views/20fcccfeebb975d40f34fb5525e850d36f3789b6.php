<?php $__env->startSection('main-body'); ?>


<!-- Start Page Title Area -->
<div class="page-title-area bg-7">
    <div class="container">
        <div class="page-title-content">
            <h2><?php echo e(__('Log In')); ?></h2>

        </div>
    </div>
</div>
<!-- End Page Title Area -->

<!-- Start Log In Area -->
<section class="user-area-all-style log-in-area ptb-100">
    <div class="container">
        <div class="contact-form-action">
            <form action="<?php echo e(route('login')); ?>" method="post">
                <div class="row">

                    <div class="col-12">
                        <div class="form-group">
                            <input class="form-control" type="text" name="email"
                              placeholder="<?php echo e(__('Username or Email')); ?>">
                        </div>
                    </div>

                    <div class="col-12">
                        <div class="form-group">
                            <input class="form-control" type="password" name="password" placeholder="<?php echo e(__(" Password")); ?>">
                        </div>
                    </div>

                    

                    <div class="col-lg-6 col-sm-6">
                        <a class="forget" href="#"><?php echo e(__('Forgot my password?')); ?></a>
                    </div>

                    <div class="col-12">
                        <button class="default-btn btn-two" type="submit">
                            <?php echo e(__('Log In Now')); ?>

                        </button>
                    </div>

                    <div class="col-12">
                        <p class="account-desc">
                            Not a member?
                            <a href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                        </p>
                    </div>
                </div>
            </form>
        </div>
    </div>
</section>
<!-- End Log In Area -->








<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.master.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tripship\resources\views/auth/login.blade.php ENDPATH**/ ?>