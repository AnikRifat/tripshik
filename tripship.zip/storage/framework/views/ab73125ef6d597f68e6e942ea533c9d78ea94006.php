<!-- Start Heder Area -->
<header class="header-area fixed-top">
    <!-- Start Navbar Area -->
    <div class="nav-area host-nav-area">
        <div class="navbar-area">
            <!-- Menu For Mobile Device -->
            <div class="mobile-nav">
                <a href="<?php echo e(route('index')); ?>" class="logo">
                    <img src="<?php echo e(asset('/')); ?>assets/front/img/logo.png" alt="Logo">
                </a>
            </div>

            <!-- Menu For Desktop Device -->
            <div class="main-nav">
                <nav class="navbar navbar-expand-md">
                    <div class="container">
                        <a class="navbar-brand" href="<?php echo e(route('index')); ?>">
                            <img src="<?php echo e(asset('/')); ?>assets/front/img/ride/logo.png" alt="Logo">
                        </a>

                        <?php echo $__env->make('front.inc.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                </nav>
            </div>
        </div>
    </div>
    <!-- End Navbar Area -->
</header>
<!-- End Heder Area -->
<?php /**PATH C:\xampp\htdocs\tripship\resources\views/front/inc/header.blade.php ENDPATH**/ ?>